Necromancer x Magical Girl

Windows x64 - 2 players, local split-screen.
Extract the entire archive and run Necromancer × Magical Girl.exe.
Choose each player's input device on the selection screen.
Menus and dialogue are in French.

Created by MAHIOU Ryad and Thibaut Hody.
